fx_version "adamant"
game "gta5"
use_fxv2_oal "yes"
lua54 "yes"

name "Fekelele_Notify"
author "Mrpsyco & Fekelele"
version "1.0.0"


shared_scripts {
    "@es_extended/imports.lua",
    "@ox_lib/init.lua",
}


client_scripts {
    "client.lua",
}


ui_page "html/index.html"

files {
    "html/index.html",
    "html/style.css",
    "html/script.js", 
    "html/notify.mp3"
}

dependencies {
    "es_extended",
}
