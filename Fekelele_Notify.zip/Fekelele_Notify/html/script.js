function createNotification(type, title, message, duration = 5000) {
    const container = document.getElementById('notificationContainer');

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.setAttribute('role', 'alert');

    const icon = {
        error: '⚠️',
        success: '✅',
        info: 'ℹ️'
    }[type] || '';

    const LabelNaame = {
        error: 'Errore',
        success: 'Successo',
        info: 'Info'
    };

    const progressBar = document.createElement('div');
    progressBar.className = 'progress-bar';

    notification.innerHTML = `
        <div class="title">
            <span class="icon">${icon}</span>
            ${LabelNaame[type] || type}
        </div>
        <div class="message">${message}</div>
    `;

    notification.appendChild(progressBar);
    container.appendChild(notification);

    progressBar.style.transitionDuration = `${duration}ms`;
    setTimeout(() => {
        progressBar.style.transform = 'scaleX(0)';
    }, 10);

    setTimeout(() => {
        notification.classList.add('show');
    }, 10);

    setTimeout(() => {
        notification.classList.remove('show');
        notification.classList.add('hide');
        setTimeout(() => notification.remove(), 400);
    }, duration);

    const sound = document.getElementById("notifySound");
    if (sound) {
        sound.currentTime = 0;
        sound.play();
    }
}

window.addEventListener('message', (event) => {
    const data = event.data;

    if (data.type === 'notification') {
        createNotification(
            data.notificationType,
            data.notificationType.toUpperCase(),
            data.message,
            data.duration || 5000
        );
    }
});
