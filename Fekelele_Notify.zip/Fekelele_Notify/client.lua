RegisterNetEvent('Fekelele_notify:showw') -- stesso nome esatto
AddEventHandler('Fekelele_notify:showw', function(message, ntype, length)
    SendNUIMessage({
        type = "notification",
        message = message,
        notificationType = ntype or 'info',
        duration = length or 5000
    })
end)


function notify(message, ntype, length)
    TriggerEvent('Fekelele_notify:show', message, ntype, length)
end

exports('notify', notify)


RegisterCommand('tes',  function()
    exports['Fekelele_Notify']:notify("Test di notifica", "info", 5000)
    exports['Fekelele_Notify']:notify("Test di notifica", "error", 5000)
    exports['Fekelele_Notify']:notify("Test di notifica", "success", 5000)
end)


RegisterCommand('dd', function()
    ESX.ShowNotification('Test info', 'info')
    ESX.ShowNotification('Test error', 'error')
    ESX.ShowNotification('Test success', 'success')
end)





